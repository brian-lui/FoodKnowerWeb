FoodKnower Press Kit Assets

This folder contains text assets referenced by the FoodKnower press page.

Included files:
- boilerplate.txt
- founder-bio.txt
- key-facts.txt
- contact.txt
- brand-colors.txt
- product-differentiators.txt
- icon.png
- scanscreen.png
- scanresult.png
- history.png
- sharecard.png

The PNG files are the press-ready image assets included with this folder:
- `icon.png`: app icon
- `scanscreen.png`: camera and scan screen
- `scanresult.png`: result screen with Food Integrity and Portion Control scores
- `history.png`: scan history screen
- `sharecard.png`: shareable score card
